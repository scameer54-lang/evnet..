# EventBid Native Flutter Android Starter

Native Flutter screens for EventBid (not a WebView). This project includes a GitHub Actions workflow to build an APK in the cloud.

For phone-only build instructions, read `BUILD_APK_ONLINE.md`.

Current screens are a starter/demo UI. EventBid's real backend, authentication, event posting, bids, chat, payments, subscriptions, and admin permissions still require integration and testing. See the original README sections below for details.

## Build locally
```bash
flutter create . --platforms=android
flutter pub get
flutter build apk --release
```
