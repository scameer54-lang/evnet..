import 'dart:convert';
import 'package:http/http.dart' as http;

/// API adapter for connecting native screens to EventBid's existing backend.
/// Do not assume the web deployment URL is an API endpoint. Configure the
/// actual backend API base URL and endpoint contracts before enabling writes.
class EventBidApi {
  static const String apiBaseUrl = String.fromEnvironment('EVENTBID_API_BASE_URL', defaultValue: '');

  static Future<ApiResult> createEvent({required String title, required String category, required String details, required String city, required String budget, DateTime? date, String? location}) async {
    if (apiBaseUrl.isEmpty) {
      return const ApiResult(false, 'Form validated. Live posting is not connected yet; configure the existing EventBid API first.');
    }
    try {
      final response = await http.post(Uri.parse('$apiBaseUrl/events'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({
        'title': title, 'category': category, 'details': details, 'city': city,
        'budget': budget, 'eventDate': date?.toIso8601String(), 'location': location,
      }));
      if (response.statusCode >= 200 && response.statusCode < 300) return const ApiResult(true, 'Event request submitted.');
      return ApiResult(false, 'API returned ${response.statusCode}. Check authentication and endpoint format.');
    } catch (_) {
      return const ApiResult(false, 'Could not reach the EventBid API. Check the API URL and network.');
    }
  }
}

class ApiResult { final bool success; final String message; const ApiResult(this.success, this.message); }
