import 'package:flutter/material.dart';
import 'screens.dart';

void main() => runApp(const EventBidApp());

class EventBidApp extends StatelessWidget {
  const EventBidApp({super.key});

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF6638B8);
    return MaterialApp(
      title: 'EventBid',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: purple, primary: purple),
        scaffoldBackgroundColor: const Color(0xFFF8F7FC),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF8F7FC), foregroundColor: Color(0xFF241B35), elevation: 0),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE5DFF0))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE5DFF0))),
        ),
      ),
      home: const AppShell(),
    );
  }
}
