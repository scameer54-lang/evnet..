# Build the EventBid APK online (no computer needed for compiling)

This project ZIP includes a GitHub Actions workflow that can compile the Flutter source into an APK. You still need a GitHub account to run the cloud build.

## Steps on your Android phone
1. Download and extract `EventBid_APK_Build_Kit.zip`.
2. In a browser, open https://github.com/new and create a new repository, e.g. `eventbid-android`. You can keep it private.
3. Upload the extracted project files to the repository's `main` branch. Make sure `.github/workflows/build-apk.yml` is included. If the mobile upload UI hides dot-folders, enable desktop site or upload the ZIP contents using GitHub's supported file upload flow; the workflow file must be present.
4. Open the repository's **Actions** tab.
5. Choose **Build EventBid Android APK** and tap **Run workflow** (or wait for the first push build).
6. Wait for the workflow to finish successfully.
7. Open that completed workflow run, find **Artifacts**, and download `eventbid-android-apk`.
8. Extract the artifact ZIP. It contains `app-release.apk`; tap it to install on your Android phone.

## Important limitations
- This builds the current Flutter starter UI, not a complete production marketplace.
- Live authentication, bids, event posting, chat, payments and admin access must be connected/tested against the actual EventBid API before production use.
- The generated release APK from this workflow is not configured with your own Play Store upload key. For Play Store publishing, configure signing with a key you control.
- Cloud builds may fail if Flutter/plugin/Android SDK compatibility changes. Open the failed Actions run to see the exact build error.
